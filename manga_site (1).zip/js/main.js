document.addEventListener("DOMContentLoaded", function() {
    console.log("Manga Reader Loaded");
});
